#include <string.h>
#include <math.h>
#include <stdio.h>
int main()
{
	int a;
         scanf ("%d",&a);
	if (a==9)
	    printf ("9\n");
	else if (a==6)
		printf ("2\n");
	return 0;
}
